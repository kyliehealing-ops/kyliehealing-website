KylieHealing.com Netlify preview with contact form.

Netlify Forms: After deploying, open your Netlify site > Forms > Enable form detection (if needed), then redeploy this folder if you enabled detection after first upload. Go to Forms > Submission notifications > Add notification > Email notification; use kyliehealing@gmail.com and form kylie-inquiries. Send a test from the public Netlify URL and confirm both dashboard submission and email delivery.

Privacy policy, Terms, image rights, full link testing and academy claims still require final review before connecting your public domain.
