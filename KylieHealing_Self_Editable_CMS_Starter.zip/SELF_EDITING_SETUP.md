# KylieHealing.com — Self-editing setup

The content files are ready for editing with [Pages CMS](https://app.pagescms.org/).
The public site currently remains a static Netlify site; the GitHub and Netlify connection is **not yet made**.

## One-time setup
1. Create/sign in to your own GitHub account.
2. Create a **private** repository, e.g. `kyliehealing-website`, and upload all files from this folder, including `.pages.yml`, `index.html`, `assets`, and `content`. GitHub's browser uploader may hide dotfiles in some workflows; verify `.pages.yml` and `netlify.toml` appear in the repository.
3. Sign in to https://app.pagescms.org using GitHub. Authorize the Pages CMS GitHub App only for that repository. Open the repository; it should show **Workshops**, **Services**, and **Art and Books** editors.
4. Connect that same GitHub repository to your **existing Netlify site** (`vermillion-beijinho-298041`) in Netlify project settings, using continuous deployment. If the interface requires extra configuration, choose publish directory `.` and no build command. Do **not** create a new public site accidentally or change Wix DNS.
5. Make a small edit in Pages CMS, save (this commits the content file to GitHub), and wait for Netlify automatic deploy. Test your existing netlify.app address.

## Editing tips
- Workshop dates and venues can be changed in separate fields, without editing HTML.
- The registration URL can be blank (the button then remains an email inquiry button). Set an `https://` URL when registration is ready.
- Service descriptions and Wise Adult text are **supplementary short summaries**; longer fixed website copy is unchanged. To make every sentence editable, the site would need a deeper content migration.
- You can change the planned Kickstarter month, but it is not a confirmed launch promise.
- Changing content here will **not** automatically change your Wix website; it updates the connected Netlify website.
- The website uses public JSON content files; do not put private client data or passwords in these files.
- The contact and waitlist forms remain Netlify Forms; entries are managed in Netlify, not Pages CMS.

## Important
The first ZIP can be manually uploaded to Netlify as a preview, but **manual uploads do not automate later CMS changes**. The GitHub-to-Netlify connection is required for self-editing to publish automatically.
